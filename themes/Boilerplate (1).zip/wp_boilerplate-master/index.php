<?php get_header() ?>

<h1>Body de la página de inicio</h1>
<?php get_sidebar() ?>

<?php get_footer() ?>