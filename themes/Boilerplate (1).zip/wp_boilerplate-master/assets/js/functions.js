(function($) {

	// Functions

})(window.jQuery);