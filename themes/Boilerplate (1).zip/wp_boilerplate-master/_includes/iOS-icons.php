<link href="<?php bloginfo('template_url') ?>/assets/ico/apple-touch-icon.png" rel="apple-touch-icon" />
<link href="<?php bloginfo('template_url') ?>/assets/ico/apple-touch-icon-76x76.png" rel="apple-touch-icon" sizes="76x76" />
<link href="<?php bloginfo('template_url') ?>/assets/ico/apple-touch-icon-120x120.png" rel="apple-touch-icon" sizes="120x120" />
<link href="<?php bloginfo('template_url') ?>/assets/ico/apple-touch-icon-152x152.png" rel="apple-touch-icon" sizes="152x152" />
<link href="<?php bloginfo('template_url') ?>/assets/ico/apple-touch-icon-180x180.png" rel="apple-touch-icon" sizes="180x180" />
<link href="<?php bloginfo('template_url') ?>/assets/ico/icon-hires.png" rel="icon" sizes="192x192" />
<link href="<?php bloginfo('template_url') ?>/assets/ico/icon-normal.png" rel="icon" sizes="128x128" />
<link href="<?php bloginfo('template_url') ?>/assets/ico/icon.svg" rel="mask-icon" sizes="any" color="#61b94c">