<?php if ( is_active_sidebar( 'sidebar-widget' ) ) { ?>
    <?php dynamic_sidebar( 'sidebar-widget' ); ?>
<?php }; ?>